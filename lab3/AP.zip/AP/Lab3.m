clear all; clc; close all;

signal = importdata("nsr001.dat"); 

% całkowanie
y = cumsum(signal - mean(signal));
x = cumsum(signal);
% transpozycja
y = y'
% x = 1:length(y);
len_signal = length(y);
n = 4;
F = [];
to_miss = rem(len_signal , n); % reszta z dzielenia 
%for n = n : 64

if n >=4 || n <= 64
    s = 0;
for i = 1: n : len_signal - (n+1) - to_miss
    % zebrac 4 probki
    c = polyfit(x(i:i+n),y(i:i+n), 1);
    % yn = polyval
    yn = polyval(c, x(i:i+n));
    y2 = yn - y(i:i+n);
    F = y2.^2;
end
end   

F
plot(F)

%W = polyfit()

