clear all; clc; close all;

signal = importdata("data/nsr001.dat");  %odstępy czasowe
y = cumsum(signal - mean(signal));
y =y.'; %transpozycja
x = 1:length(y);

F = [];

n=4;

Ynk = [];
i=1;
while i<length(y)-n
   if i + n >=length(y)-n
       pf=4
   end
       
   x1 = i:i+(n-1);
   p = polyfit(x1,y(x1),2);
   ynk = polyval(p,x1);
   
   Ynk = [Ynk , ynk];
   i = i + n;
end

suma = (y - Ynk)^2
F(end+1) = sqrt(1/length(y) * suma);

%     
% x = linspace(0,4*pi,10);
% y = sin(x);
% p = polyfit(x,y,1);
% x1 = linspace(0,4*pi);
% y1 = polyval(p,x1);
% figure
% plot(x,y,'o')
% hold on
% plot(x1,y1)
% hold off


% function output = pls(signal, x)
%     tau = 1/(4*pi*f) * atan(sum(sin(4*pi*f*t_k))/sum(cos(4*pi*f*t_k)));
% 
%     part1 = sum(x .* cos(2*pi*f*(t_k - tau))).^2;
%     part2 = sum(cos(2*pi*f*(t_k - tau)).^2);
% 
%     part3 = sum(x .* sin(2*pi*f*(t_k - tau))).^2;
%     part4 = sum(sin(2*pi*f*(t_k - tau)).^2);
% 
%     output = 0.5 * ( part1/part2 + part3/part4 );
% 
% end